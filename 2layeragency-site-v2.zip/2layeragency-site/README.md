# 2layeragency website

Single-page site (index.html) + privacy.html, terms.html, PWA files. No build step: upload the folder to any static host (Netlify, Vercel, Cloudflare Pages, GitHub Pages, cPanel).

## Edit in one place
Open index.html and search for `CONFIG`. There are two blocks:
- Main CONFIG: brand, email, phone, WhatsApp numbers, colours, marquee text, work videos (set `src` and `poster` per video).
- EXTRA CONFIG (near the end of the file): `BOOK_URL` (Calendly/Cal.com link), `GA_ID` (Google Analytics), `social` (profile URLs; empty ones are hidden).

## Before going live
1. Replace the placeholder pricing, case-study text, FAQ answers and testimonials with your real ones (search for `id="pricing"`, `id="results"`, `id="faq"`, `class="tm"`).
2. Add real video files in CONFIG (shortForm / podcast lists).
3. Paste your Calendly link into BOOK_URL.
4. Fill in your social URLs.
5. After you have a domain: change og:image in <head> to the full URL (https://yourdomain/icon-512.png), add a canonical link, and add a sitemap.xml.
6. Have privacy.html and terms.html reviewed for your situation.
